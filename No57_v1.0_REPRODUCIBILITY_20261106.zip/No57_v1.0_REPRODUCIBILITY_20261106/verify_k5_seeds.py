#!/usr/bin/env python3
"""No.57 v0.8.1 editorial repair: verify K5 seed completeness and all cuts.

Exact integer check on explicit right-vertex neighbor lists. This is a finite
verification of witness trees, not a substitute for the symbolic extension lemma.
Only Python standard library is required.
"""
K = 5
SEEDS = {
    54: (10, 10, 10, 10, 10),
    55: (11, 10, 10, 10, 10),
    58: (10, 11, 11, 11, 11),
    59: (11, 11, 11, 11, 11),
    60: (11, 12, 11, 11, 11),
    61: (12, 12, 11, 11, 11),
    62: (10, 12, 12, 12, 12),
}

def max_score_for_mask(mask, edges, n):
    a = mask.bit_count()
    d = K - 2 * a
    score = -2 * a * n
    for left_neighbors in edges:
        j = sum((mask >> v) & 1 for v in left_neighbors)
        score += max(K*j, K*(len(left_neighbors)-j) - 2*d)
    return score

def check():
    assert set(SEEDS) == {54,55,58,59,60,61,62}
    assert set(range(58,63)).issubset(SEEDS), 'Missing one residue class modulo 5'
    for n, counts in sorted(SEEDS.items()):
        assert len(counts)==K and min(counts)>=0
        assert sum(counts) == n-(K-1)
        edges = [(0,i) for i in range(1,K)]
        for left,amount in enumerate(counts):
            edges.extend([(left,)]*amount)
        assert len(edges)==n
        values=[max_score_for_mask(mask, edges, n) for mask in range(1<<K)]
        assert max(values)==0, (n,max(values))
        assert all(v<=0 for v in values), n
        # Singleton cut at a degree-two right connector has ratio 2/5,
        # establishing the matching lower bound independently of this loop.
        print(f'PASS K5 n={n}: {len(edges)} right vertices; all 32 left masks; max(5T-2G)=0')
    # Explicit star formula at n=62, independent of the neighbor-list loop.
    n=62;c=10;y=[12,12,12,12];N=c+sum(y)
    def star_scores(a):
        u=max(0,4*a-K)
        fout=-2*a*n+u*N+(K-u)*sum(y[:a])+a*(5*K-4-4*a)
        fin=-2*a*n+u*N+(K-u)*(c+sum(y[:a-1]))+K*(K+a-2)
        return fout,fin
    assert (star_scores(1),star_scores(2)) == ((-47,-54),(0,-5))
    print('PASS K5 n=62 exact star scores (-47,-54,0,-5)')
    print('ALL PASS: K5 witness seeds cover every residue class modulo five')

if __name__ == '__main__':
    check()
