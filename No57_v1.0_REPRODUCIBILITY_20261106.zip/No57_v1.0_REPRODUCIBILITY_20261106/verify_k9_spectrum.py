#!/usr/bin/env python3
"""No.57 K9 supplement: exact-integer independent witness and obstruction checks.
Standard library only; does NOT independently prove structural/centroid lemmas.
"""
from itertools import combinations
from math import comb

K=9
WITNESSES={
 332:(36,36,36,36,36,36,36,36,36),
 333:(37,36,36,36,36,36,36,36,36),
 340:(36,37,37,37,37,37,37,37,37),
 341:(37,37,37,37,37,37,37,37,37),
 342:(37,38,37,37,37,37,37,37,37),
 343:(38,38,37,37,37,37,37,37,37),
 348:(36,38,38,38,38,38,38,38,38),
 349:(37,38,38,38,38,38,38,38,38),
 350:(38,39,38,38,38,38,38,38,37),
 351:(39,39,38,38,38,38,38,38,37),
 352:(38,39,39,38,38,38,38,38,38),
 353:(39,39,39,38,38,38,38,38,38),
 356:(36,39,39,39,39,39,39,39,39),
 357:(37,39,39,39,39,39,39,39,39),
 358:(39,40,39,39,39,39,39,38,38),
 359:(40,40,39,39,39,39,39,38,38),
 360:(38,40,40,39,39,39,39,39,39),
 361:(39,40,40,39,39,39,39,39,39),
 362:(39,40,40,40,39,39,39,39,39),
 363:(40,40,40,40,39,39,39,39,39),
 364:(36,40,40,40,40,40,40,40,40),
}
HOLES=list(range(334,340))+list(range(344,348))+[354,355]

def construct_right_neighbors(x):
    # Eight distinct degree-2 connectors with skeleton center 0 -> 1..8.
    return [tuple([0,j]) for j in range(1,9)] + [(i,) for i,q in enumerate(x) for _ in range(q)]

def score_max_for_left_mask(mask, right_neighbors, n):
    a=mask.bit_count(); z=K-2*a
    score=-2*a*n
    for e in right_neighbors:
        j=sum((mask>>i)&1 for i in e)
        score+=max(K*j, K*(len(e)-j)-2*z)
    return score

def verify_positive():
    for n,x in sorted(WITNESSES.items()):
        assert len(x)==K and all(isinstance(v,int) and v>=0 for v in x)
        assert sum(x)==n-(K-1),(n,sum(x))
        neighbors=construct_right_neighbors(x)
        assert len(neighbors)==n
        scores=[score_max_for_left_mask(mask,neighbors,n) for mask in range(1<<K)]
        worst=max(scores)
        assert worst==0,(n,worst)
        print(f'PASS K9 n={n} all 512 left masks, {n} explicit right vertices; max(9T-2G)={worst}')
    print('PASS all 21 positive witnesses')

def verify_holes():
    for n in HOLES:
        # For any star witness, let c=center leaves and y1>=...>=y8.
        # 4-set cuts yield top4(y)<=P and c+top3(y)<=Q.
        # y4<=floor(P/4), and sum(y4..y8)<=5*y4.
        # Therefore c+top3 >= n-8-5floor(P/4), which is >Q at all holes.
        P=(n-44)//2; Q=(n-43)//2
        obstruction=(n-8)-5*(P//4)-Q
        assert obstruction>0,(n,obstruction)
        assert n<376
        print(f'PASS n={n} star obstruction surplus={obstruction}; nonstar cutoff=376')
    print('PASS all 12 exact arithmetical hole certificates')

def verify_closure():
    for a in range(1,5):
        delta=-9*a+(9-a)*max(0,4*a-9)
        assert delta<0,(a,delta)
        print(f'PASS plus-9 leaf extension, a={a}, score difference {delta}')
    assert set(range(356,365)).issubset(WITNESSES)
    print('PASS nine consecutive seeds -> all n>=356')

def verify_weighted_identity():
    # Check the newly used k=9 identity on explicit H with arbitrary leaf vectors.
    # W: four copies of A + five four-sets of its complement.
    H=[(0,j) for j in range(1,9)]
    A={0,1,2,3}; B=set(range(9))-A
    x=WITNESSES[332];n=332
    W=[A]*4 + [set(v) for v in combinations(sorted(B),4)]
    def s(C):
        ei=sum(u in C and v in C for u,v in H)
        eo=sum(u not in C and v not in C for u,v in H)
        return n-16-9*ei-7*eo-2*sum(x[i] for i in C)
    ei=sum(u in A and v in A for u,v in H)
    eo=sum(u in B and v in B for u,v in H)
    E=4*ei+3*eo
    assert sum(s(C) for C in W) == n-136-16*E
    assert all(sum(v in C for C in W)==4 for v in range(9))
    print('PASS exact k=9 weighted 9-set slack identity')

if __name__=='__main__':
    verify_positive(); verify_holes(); verify_closure(); verify_weighted_identity()
    print('ALL PASS: independent integer crosschecks (symbolic lemmas are separate)')
